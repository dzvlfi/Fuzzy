Eksekusi menggunakan python pada cmd/ terminal
Masukkan nilai keanggotaan emosi, tekan enter
lalu masukkan nilai keanggotaan provokasi, tekan enter
hasil akan muncul

Dzulfiqar Ridha, 1301154298, IF-39-04